package day12;

import java.util.ArrayList;

public class Student {
	
	protected int rollno;
	protected String name;
	protected int marks ;
	
	
}
