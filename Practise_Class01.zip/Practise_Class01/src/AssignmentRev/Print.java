package AssignmentRev;

public interface Print {
	void print();
}
