package AssignmentRev;

public class College {
	public static void main(String[] args) {
		
	}
}
