package AssignmentRev;

public interface Write {
	void printToFile();
	void printToDB();
}
