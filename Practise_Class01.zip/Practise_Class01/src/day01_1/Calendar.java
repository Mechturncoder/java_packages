package day01_1;

public class Calendar {
		public static void main(String[] args) {
			int i = 9;
			System.out.println(i);
			Date d1 = new Date(2,"Sept", 2024);
			System.out.println(d1);
		}
	}

