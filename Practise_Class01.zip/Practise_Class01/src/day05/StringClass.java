package day05;

public class StringClass {

}
