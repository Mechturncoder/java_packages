package day10;

public class Counter {
	
	int count;

	public int getCount() {
		return count;
	}
	
	public int increment() {
		
		count++;
		return count;
		
	}
}
