package day06;

public class MultiplesException extends Exception{
	public MultiplesException(String message) {
		
		super(message);	
	}
}
