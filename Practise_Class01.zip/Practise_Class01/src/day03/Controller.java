package day03;

public class Controller {
	public static void main(String[] args) {
		Curtain remote = new Curtain();
		// System.out.println(c.isOn());
		remote.turnOn();
		remote.turnOff();
	}
}
