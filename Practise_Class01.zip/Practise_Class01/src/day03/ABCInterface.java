package day03;

public interface ABCInterface {
	void seeBalance(Account a, Account b, Account c);
	void withDraw(Account a, double money);
	void seeProcessing();
}
