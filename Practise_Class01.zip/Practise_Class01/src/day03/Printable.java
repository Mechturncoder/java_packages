package day03;

public interface Printable {
	void print();
}
