package day03;

public interface TaxPayer {
	double calculateTax();
}
