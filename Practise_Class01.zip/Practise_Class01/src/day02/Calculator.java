package day02;

public class Calculator {
	public static void add(int a , int b) {
		System.out.println(a+b);
	}
}
