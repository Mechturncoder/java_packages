package day08;

public interface Function <T>{
	T apply(T data);
}
