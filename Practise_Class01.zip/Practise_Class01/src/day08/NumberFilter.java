package day08;

public interface NumberFilter {
	boolean test(int n);
}
