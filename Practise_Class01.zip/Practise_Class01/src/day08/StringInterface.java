package day08;

public interface StringInterface {
	String apply(String s);
}
